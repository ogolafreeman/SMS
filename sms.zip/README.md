# SMS

Student Management System for Richmond College A/L Section.

> Coding :

- Version : 1.0
- Base Language : PHP (v8.1)
- Used Language/s : HTML, CSS, JavaScript, SQL (MySQL)
- Framework : Bootstrap (CSS Framework)
- Used Pre Trained models/ APIs : -
- Platform : Any (Windows, MacOS, Linux, iOS, Android etc.)
- Environments : [Visual Studio Code](https://code.visualstudio.com/download)
- Servers : [XAMPP](https://www.apachefriends.org/download.html) (Also compatible with WAMP, MAMP, LAMP)

> Project Details :

- For : Richmond College A/L Section | YCS
- Project Progress : 47%
- Start Date : 12.03.2023
- End Date : Pending...
- Release Date : Pending...
- Further Updates : Disabled
