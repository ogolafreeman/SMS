========== VERSIONS ==========
Bootstrap - 5.2
jquery - 3.6.3
datatables - 1.10.25