<footer class="py-4 bg-light mt-auto">
    <div class="container-fluid px-4">
        <div class="d-flex align-items-center justify-content-between small">
            <div class="text-muted">Copyright &copy; RCTS
                <?php echo date("Y"); ?>
            </div>
            <div>
                <a href="https://www.techsaralk.epizy.com/" title="Official website of Techසර LK">Techසර LK</a>
                &middot;
                <a href="https://www.youtube.com/@techsaralk/" title="Techසර LK YouTube Channel">Dasun Nethsara</a>
            </div>
        </div>
    </div>
</footer>